import React from "react";

const Movies = () => {
	return <div>Movies들을 나열, 왼쪽에 sort,filter</div>;
};

export default Movies;
